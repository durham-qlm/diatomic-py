import setuptools

setuptools.setup( 
		name="diatom",
		version='1.0.0',
		author='J. A. Blackmore',
		author_email = 'j.a.blackmore@durham.ac.uk',
		packages=['diatom','diatom.test'],
		package_data={'':['*.txt']},
		project_urls={'Source code':'https://github.com/JakeBlackmore/Diatom'},
		license='Creative Commons Attribution-Noncommercial-Share Alike license',
		description = 'Hamiltonian for diatomics',
		long_description=open('readme.txt').read()
	)
