# Diatomic-Py
Python module to calculate the hyperfine energy levels of singlet sigma diatomic molecules. Included are examples from the bialkali series : RbCs, KCs and KRb

The hyperfine structure can be calculated in static electric and magnetic fields and, when provided the polarisability, oscillating electric fields.
